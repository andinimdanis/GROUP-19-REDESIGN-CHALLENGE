const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:3000/api/v1";

// contoh GET tanpa endpoint utama
export async function getData() {
  try {
    const res = await fetch(`${BASE_URL}/endpoint1`);
    if (!res.ok) throw new Error("Failed to fetch data");
    return await res.json();
  } catch (err) {
    console.error("GET error:", err);
    throw err;
  }
}

// contoh POST tanpa endpoint utama
export async function postData(payload) {
  try {
    const res = await fetch(`${BASE_URL}/endpoint2`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error("Failed to post data");
    return await res.json();
  } catch (err) {
    console.error("POST error:", err);
    throw err;
  }
}
