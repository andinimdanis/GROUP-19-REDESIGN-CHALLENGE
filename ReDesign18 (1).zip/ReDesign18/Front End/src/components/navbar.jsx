import React from 'react';

const Navbar = () => (
  <nav className="bg-white shadow fixed top-0 w-full z-50">
    <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <div className="bg-[#64300B] w-[53px] h-[49px] rounded-[10px] flex items-center justify-center">
          <img src="https://upload.wikimedia.org/wikipedia/commons/4/4f/LOGO_UNSRI.png" alt="Logo" className="w-10 h-10" />
        </div>
        <span className="font-semibold text-lg text-[#64300B]">Fakultas Ilmu Komputer<br/>Universitas Sriwijaya</span>
      </div>
      <ul className="hidden md:flex space-x-6 text-gray-700 font-medium">
        <li><a href="#" className="hover:text-yellow-600">Beranda</a></li>
        <li><a href="#" className="hover:text-yellow-600">Profil</a></li>
        <li><a href="#" className="hover:text-yellow-600">Jurusan & Unit</a></li>
        <li><a href="#" className="hover:text-yellow-600">Dosen & Staf</a></li>
        <li><a href="#" className="hover:text-yellow-600">PPID</a></li>
        <li><a href="#" className="hover:text-yellow-600">Zona Integritas</a></li>
      </ul>
      <div className="relative group">
        <input type="text" placeholder="Cari sesuatu..."
          className="w-44 group-hover:w-56 transition-all duration-300 ease-in-out pl-10 pr-4 py-2 rounded-full border border-[#64300B] bg-[#64300B] text-white placeholder-white focus:outline-none focus:ring-2 focus:ring-[#cb7e4a]" />
        <svg xmlns="http://www.w3.org/2000/svg" className="w-5 h-5 absolute left-3 top-2.5 text-white group-hover:text-white transition-colors duration-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
      </div>
    </div>
  </nav>
);

export default Navbar;