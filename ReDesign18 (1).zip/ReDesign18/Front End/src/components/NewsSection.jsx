import React from 'react';
import NewsCard from './NewsCard';

const NewsSection = ({ data, isLoading }) => {
  if (isLoading) {
    return <div>Loading berita...</div>;
  }

  return (
    <div className="flex flex-col">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-[#64300B] text-3xl font-bold">Berita & Informasi</h2>
        <a href="#" className="w-11 h-11 bg-[#FFD45C] rounded-full flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-[#64300B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </a>
      </div>
      <div className="flex flex-col space-y-2">
        {data.map(item => (
          <NewsCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
};

export default NewsSection;