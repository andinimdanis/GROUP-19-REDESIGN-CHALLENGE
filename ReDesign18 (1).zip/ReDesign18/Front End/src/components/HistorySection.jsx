import React from 'react';

const HistorySection = () => (
  <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start mb-16">
    <div className="flex flex-col">
      <div className="relative w-full aspect-video rounded-lg overflow-hidden mb-4 bg-black">
        <iframe className="absolute top-0 left-0 w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen></iframe>
      </div>
      <div className="flex space-x-2">
        <div className="relative w-1/3 aspect-video rounded-lg overflow-hidden">
          <iframe className="absolute top-0 left-0 w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameBorder="0" allowFullScreen></iframe>
        </div>
        <div className="relative w-1/3 aspect-video rounded-lg overflow-hidden">
          <iframe className="absolute top-0 left-0 w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameBorder="0" allowFullScreen></iframe>
        </div>
        <div className="relative w-1/3 aspect-video rounded-lg overflow-hidden">
          <iframe className="absolute top-0 left-0 w-full h-full" src="https://www.youtube.com/embed/dQw4w9WgXcQ" frameBorder="0" allowFullScreen></iframe>
        </div>
      </div>
    </div>
    <div className="flex flex-col">
      <div className="relative w-full h-auto">
        <div className="text-amber-900 text-4xl md:text-5xl font-bold mb-4">Sejarah Fakultas</div>
        <div className="w-full text-justify text-neutral-800 text-base md:text-xl font-medium mb-8">Berdirinya Fakultas Ilmu Komputer didahului dengan Program Diploma Komputer UNSRI baru yang berdiri di pertengahan tahun 2003, tepatnya tanggal 5 September 2003 dan merupakan program pendidikan bidang ICT yang pertama di Universitas Sriwijaya.</div>
        <div className="flex flex-col space-y-2">
          <div className="flex justify-start space-x-2">
            <div className="w-[141px] h-[90px] bg-[#64300B] text-white rounded-[10px] p-2 flex flex-col justify-center items-start shadow-md">
              <div className="text-2xl md:text-3xl font-bold">2000+</div>
              <div className="text-base font-medium">Alumni</div>
            </div>
            <div className="w-[141px] h-[90px] bg-[#FFD45C] text-[#272727] rounded-[10px] p-2 flex flex-col justify-center items-start shadow-md">
              <div className="text-2xl md:text-3xl font-bold">30+</div>
              <div className="text-base font-medium">Dosen</div>
            </div>
            <div className="w-[141px] h-[90px] bg-[#FFD45C] text-[#272727] rounded-[10px] p-2 flex flex-col justify-center items-start shadow-md">
              <div className="text-2xl md:text-3xl font-bold">20+</div>
              <div className="text-base font-medium">Staf</div>
            </div>
          </div>
          <div className="flex justify-start space-x-2">
            <div className="w-[141px] h-[90px] bg-[#64300B] text-white rounded-[10px] p-2 flex flex-col justify-center items-start shadow-md">
              <div className="text-2xl md:text-3xl font-bold">1500+</div>
              <div className="text-base font-medium">Mahasiswa</div>
            </div>
            <div className="w-[141px] h-[90px] bg-[#64300B] text-white rounded-[10px] p-2 flex flex-col justify-center items-start shadow-md">
              <div className="text-2xl md:text-3xl font-bold">10+</div>
              <div className="text-base font-medium">Ormawa</div>
            </div>
            <div className="w-[141px] h-[90px] bg-[#FFD45C] text-[#272727] rounded-[10px] p-2 flex flex-col justify-center items-start shadow-md">
              <div className="text-2xl md:text-3xl font-bold">25+</div>
              <div className="text-base font-medium">Riset</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default HistorySection;