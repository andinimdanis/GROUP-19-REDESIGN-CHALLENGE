import React from 'react';

const GallerySection = () => (
  <div className="flex flex-col px-6 mt-8 lg:mt-0">
    <div className="flex items-center justify-between mb-8">
      <h3 className="text-4xl font-bold text-amber-900 leading-[90px] whitespace-nowrap overflow-hidden text-ellipsis">Galeri Kegiatan FASILKOM</h3>
      <a href="#" className="w-11 h-11 bg-[#FFD45C] rounded-full flex items-center justify-center flex-shrink-0 ml-4">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-[#64300B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
      </a>
    </div>
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
      <div className="col-span-1 row-span-2">
        <img src="ReDesign18/src/assets/berita1.png" alt="Galeri 1" className="w-full h-full object-cover rounded-[10px] border border-amber-900/20 hover:shadow-xl transition duration-300" />
      </div>
      <div className="col-span-1 flex flex-col gap-4">
        <img src="ReDesign18/src/assets/berita2.png" alt="Galeri 2" className="w-full h-full object-cover rounded-[10px] border border-amber-900/20 hover:shadow-xl transition duration-300" />
        <img src="ReDesign18/src/assets/berita2.png" alt="Galeri 3" className="w-full h-full object-cover rounded-[10px] border border-amber-900/20 hover:shadow-xl transition duration-300" />
      </div>
      <div className="col-span-1 row-span-2 hidden lg:block">
        <img src="ReDesign18/src/assets/poster4.png" alt="Galeri 4" className="w-full h-full object-cover rounded-[10px] border border-amber-900/20 hover:shadow-xl transition duration-300" />
      </div>
    </div>
  </div>
);

export default GallerySection;