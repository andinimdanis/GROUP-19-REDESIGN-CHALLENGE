import React from 'react';

const HeroSection = () => (
  <div className="relative w-full min-h-screen bg-cover bg-center pt-16"
    style={{ backgroundImage: <img src="/components/hero.png" alt="Foto 1" className="w-full h-full object-cover"/> }}>
    <div className="absolute inset-0 bg-black opacity-50"></div>
    <div className="relative container mx-auto px-6 py-24 min-h-screen flex flex-col md:grid md:grid-cols-2 gap-8 items-center">
      <div className="flex flex-col items-start text-left text-white z-10 w-full md:pr-12">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold leading-tight tracking-tight mb-4">
          Selamat Datang di Fakultas Ilmu Komputer Universitas Sriwijaya
        </h1>
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
          <a href="#" className="inline-block px-8 py-3 bg-[#64300B] text-white text-lg font-semibold rounded-full shadow-lg transition-all duration-300 transform hover:scale-105 hover:bg-[#8d440f]">
            Pelajari Lebih Lanjut
          </a>
          <a href="#" className="inline-block px-8 py-3 bg-transparent text-white text-lg font-semibold rounded-full border border-white transition-all duration-300 transform hover:scale-105 hover:bg-white hover:text-[#64300B]">
            Hubungi Kami
          </a>
        </div>
      </div>
      <div className="hidden md:flex flex-col space-y-8 items-center justify-center w-full z-10">
        <div className="relative w-[536px] h-64">
          <div className="w-16 h-16 absolute top-0 right-0 bg-amber-900 rounded-[10px]"></div>
          <div className="w-16 h-16 absolute bottom-0 left-0 bg-amber-900 rounded-[10px]"></div>
          <div className="w-[514px] h-60 absolute top-[12px] left-[12px] rounded-[10px] overflow-hidden border-4 border-[#FFD45C]">
            <img src="ReDesign18/src/assets/fasilBukit.png" alt="Foto 1" className="w-full h-full object-cover"/>
          </div>
        </div>
        <div className="relative w-[536px] h-64">
          <div className="w-16 h-16 absolute top-0 left-0 bg-amber-900 rounded-[10px]"></div>
          <div className="w-16 h-16 absolute bottom-0 right-0 bg-amber-900 rounded-[10px]"></div>
          <div className="w-[514px] h-60 absolute top-[11px] left-[12px] rounded-[10px] overflow-hidden border-4 border-[#FFD45C]">
            <img src="ReDesign18/src/assets/fasilLayo.png" alt="Foto 2" className="w-full h-full object-cover"/>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default HeroSection;