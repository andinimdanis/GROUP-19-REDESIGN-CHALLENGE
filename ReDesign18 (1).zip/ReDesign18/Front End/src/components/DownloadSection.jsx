import React from 'react';

const DownloadSection = () => (
  <div>
    <div className="flex items-center justify-between mb-8">
      <h2 className="text-amber-900 text-3xl font-bold">Download</h2>
      <a href="#" className="w-11 h-11 bg-[#FFD45C] rounded-full flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-[#64300B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
      </a>
    </div>
    <div className="flex flex-col space-y-3">
      <a href="#" className="block text-neutral-800 text-base font-bold">SOP PPT FASILKOM</a>
      <div className="w-full border-t border-gray-300"></div>
      <a href="#" className="block text-neutral-800 text-base font-bold">Akreditasi UNSRI</a>
      <div className="w-full border-t border-gray-300"></div>
    </div>
  </div>
);

export default DownloadSection;