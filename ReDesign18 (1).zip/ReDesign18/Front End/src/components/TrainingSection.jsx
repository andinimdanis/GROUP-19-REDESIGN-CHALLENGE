import React from 'react';

const TrainingSection = () => (
  <section className="w-full p-8 mb-16">
    <div className="flex items-center justify-between mb-12">
      <h2 className="text-amber-900 text-3xl font-bold">Pelatihan dan Sertifikasi</h2>
      <a href="#" className="inline-flex items-center">
        <div className="w-11 h-11 bg-[#FFD45C] rounded-full flex items-center justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-[#64300B]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </div>
      </a>
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4" style={{ gap: '50px' }}>
      <a href="#" className="block h-full">
        <div className="w-full h-full bg-white rounded-[10px] overflow-hidden shadow-md transition-shadow hover:shadow-lg flex flex-col">
          <div className="relative rounded-[10px] border border-amber-900">
            <img className="w-full h-auto aspect-square object-cover rounded-[10px]" src="https://placehold.co/280x280" alt="Oracle Database Foundation" />
            <div className="absolute top-2 right-2 w-20 h-12 bg-amber-300 rounded-[10px] border border-amber-900 flex items-center justify-center">
              <span className="text-amber-900 text-base font-bold">GRATIS</span>
            </div>
          </div>
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div className="flex flex-col">
              <h3 className="text-neutral-800 text-sm font-bold truncate mb-3">Oracle Database Foundation</h3>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Tanggal: Sep 30 - 3 Okt 2025</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Lokasi: Lab FASILKOM Palembang</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Jam: 08.00 - 12.00 WIB</p>
            </div>
            <div className="mt-4 w-full h-12 bg-amber-900 rounded-[60px] flex items-center justify-center">
              <span className="text-amber-300 text-base font-bold">DAFTAR DI SINI</span>
            </div>
          </div>
        </div>
      </a>
      <a href="#" className="block h-full">
        <div className="w-full h-full bg-white rounded-[10px] overflow-hidden shadow-md transition-shadow hover:shadow-lg flex flex-col">
          <div className="relative rounded-[10px] border border-amber-900">
            <img className="w-full h-auto aspect-square object-cover rounded-[10px]" src="https://placehold.co/280x280" alt="Arduino Certification" />
            <div className="absolute top-2 right-2 w-20 h-12 bg-amber-300 rounded-[10px] border border-amber-900 flex items-center justify-center">
              <span className="text-amber-900 text-base font-bold">GRATIS</span>
            </div>
          </div>
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div className="flex flex-col">
              <h3 className="text-neutral-800 text-sm font-bold truncate mb-3">Arduino Certification</h3>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Tanggal: 13, 20, 27 Sep 2025</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Lokasi: Lab FASILKOM Palembang</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Jam: 09.00 - 12.00 WIB</p>
            </div>
            <div className="mt-4 w-full h-12 bg-amber-900 rounded-[60px] flex items-center justify-center">
              <span className="text-amber-300 text-base font-bold">DAFTAR DI SINI</span>
            </div>
          </div>
        </div>
      </a>
      <a href="#" className="block h-full">
        <div className="w-full h-full bg-white rounded-[10px] overflow-hidden shadow-md transition-shadow hover:shadow-lg flex flex-col">
          <div className="relative rounded-[10px] border border-amber-900">
            <img className="w-full h-auto aspect-square object-cover rounded-[10px]" src="https://placehold.co/280x280" alt="Generative AI for Learn & Ethics" />
            <div className="absolute top-2 right-2 w-20 h-12 bg-amber-300 rounded-[10px] border border-amber-900 flex items-center justify-center">
              <span className="text-amber-900 text-base font-bold">GRATIS</span>
            </div>
          </div>
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div className="flex flex-col">
              <h3 className="text-neutral-800 text-sm font-bold truncate mb-3">Generative AI for Learn & Ethics</h3>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Tanggal: Rabu, 6 Agustus 2025</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Lokasi: Zoom Meeting</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Jam: 09.00 - 12.00 WIB</p>
            </div>
            <div className="mt-4 w-full h-12 bg-amber-900 rounded-[60px] flex items-center justify-center">
              <span className="text-amber-300 text-base font-bold">DAFTAR DI SINI</span>
            </div>
          </div>
        </div>
      </a>
      <a href="#" className="block h-full">
        <div className="w-full h-full bg-white rounded-[10px] overflow-hidden shadow-md transition-shadow hover:shadow-lg flex flex-col">
          <div className="relative rounded-[10px] border border-amber-900">
            <img className="w-full h-auto aspect-square object-cover rounded-[10px]" src="https://placehold.co/280x280" alt="Training & Test Certification" />
            <div className="absolute top-2 right-2 w-20 h-12 bg-amber-300 rounded-[10px] border border-amber-900 flex items-center justify-center">
              <span className="text-amber-900 text-base font-bold">GRATIS</span>
            </div>
          </div>
          <div className="p-5 flex-1 flex flex-col justify-between">
            <div className="flex flex-col">
              <h3 className="text-neutral-800 text-sm font-bold truncate mb-3">Training & Test Certification</h3>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Tanggal: Sep 30 - 3 Okt 2025</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Lokasi: Lab FASILKOM Palembang</p>
              <p className="text-neutral-700 text-base font-normal whitespace-nowrap leading-tight">Jam: 08.00 - 12.00 WIB</p>
            </div>
            <div className="mt-4 w-full h-12 bg-amber-900 rounded-[60px] flex items-center justify-center">
              <span className="text-amber-300 text-base font-bold">DAFTAR DI SINI</span>
            </div>
          </div>
        </div>
      </a>
    </div>
  </section>
);

export default TrainingSection;