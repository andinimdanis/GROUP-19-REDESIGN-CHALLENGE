import React from 'react';

const NewsCard = ({ item }) => (
  <a href="#" className="block w-full bg-white rounded-[10px] border border-[#64300B] overflow-hidden flex flex-col sm:flex-row items-stretch transition-shadow duration-300 hover:shadow-lg">
    <img className="w-full sm:w-44 h-auto sm:h-24 object-cover rounded-tl-[10px] sm:rounded-bl-[10px] sm:rounded-tr-none" src={item.image} alt={item.title} />
    <div className="p-4 sm:p-4 flex-1 flex flex-col justify-between">
      <p className="text-neutral-800 text-base font-bold mb-1">{item.title}</p>
      <div className="flex flex-col">
        <p className="text-neutral-700 text-base font-normal">{item.date} | {item.comments}</p>
      </div>
    </div>
  </a>
);

export default NewsCard;