import React from 'react';

const Footer = () => (
  <footer className="bg-gradient-to-br from-[#FFD45C] to-[#64300B] text-white mt-16">
    <div className="container mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="flex flex-col justify-between">
        <div className="pb-4">
          <h4 className="text-[#64300B] text-[31px] font-bold mb-4">Kampus Indralaya</h4>
          <p className="text-sm">Jl. Palembang - Prabumulih No.KM.32, Indralaya Indah, Kec. Indralaya, Kabupaten Ogan Ilir, Sumatera Selatan 30862</p>
        </div>
        <div className="w-full h-px bg-[#64300B] my-4 md:hidden"></div>
        <div className="pt-4">
          <h4 className="text-[#64300B] text-[31px] font-bold mb-4">Kampus Palembang</h4>
          <p className="text-sm">Jl. Srijaya Negara, Bukit Besar, Kec. Ilir Bar. I, Kota Palembang, Sumatera Selatan 30128</p>
        </div>
      </div>
      <div className="relative">
        <div className="absolute top-0 bottom-0 left-0 w-px bg-[#64300B] hidden md:block"></div>
        <div className="md:pl-8">
          <h4 className="text-[#64300B] text-[31px] font-bold mb-4">Kontak</h4>
          <ul className="space-y-4 text-sm">
            <li className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
              <span>+62 711 580060</span>
            </li>
            <li className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12h-5z"></path></svg>
              <span>fasikom@unsri.ac.id</span>
            </li>
            <li className="flex items-center space-x-2">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
              <span>Google Maps</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="relative">
        <div className="absolute top-0 bottom-0 left-0 w-px bg-[#64300B] hidden md:block"></div>
        <div className="md:pl-8">
          <h4 className="text-[#64300B] text-[31px] font-bold mb-4">Media Sosial</h4>
          <div className="flex space-x-4">
            <a href="#" aria-label="YouTube" className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
              <img src="https://upload.wikimedia.org/wikipedia/commons/4/42/YouTube_icon_%282017%29.svg" alt="YouTube" className="w-6 h-6"/>
            </a>
            <a href="#" aria-label="Facebook" className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
              <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" alt="Facebook" className="w-6 h-6"/>
            </a>
            <a href="#" aria-label="Instagram" className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
              <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="Instagram" className="w-6 h-6"/>
            </a>
          </div>
        </div>
      </div>
    </div>
    <div className="text-center py-4 text-xs">
      Copyright © Fakultas Ilmu Komputer Universitas Sriwijaya. All Rights Reserved
    </div>
  </footer>
);

export default Footer;