import React from 'react';

const NavigationLinksSection = () => (
  <div className="flex flex-col px-6">
    <div className="flex items-center justify-between mb-8">
      <h3 className="text-4xl font-bold text-amber-900 leading-[90px]">Tautan Navigasi</h3>
    </div>
    <ul className="space-y-4">
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Kemahasiswaan & Kerja Sama
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Akademik & Penelitian
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Lowongan Pekerjaan
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Kuliah Unggulan
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Layanan ICT
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Media Sosial Ormawa Fakultas
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Statistik Mahasiswa
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Beasiswa
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
      <li className="pb-2">
        <a href="#" className="text-lg font-bold text-gray-700 hover:text-amber-900 transition duration-300">
          Administrasi
        </a>
        <div className="w-2/3 h-px bg-gray-300 mt-2"></div>
      </li>
    </ul>
  </div>
);

export default NavigationLinksSection;