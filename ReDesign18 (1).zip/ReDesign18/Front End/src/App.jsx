import React from 'react';
import Header from './components/navbar';
import NewsSection from './components/NewsSection';
import ResearchTeamSection from './components/ResearchTeamSection';
import DownloadSection from './components/DownloadSection';
import TrainingSection from './components/TrainingSection';
import GallerySection from './components/GallerySection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-white">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
          <NewsSection />
          <ResearchTeamSection />
          <DownloadSection />
        </section>
        <section className="mb-8">
          <TrainingSection />
        </section>
        <section className="mb-8">
          <GallerySection />
        </section>
      </main>
      <Footer />
    </div>
  );
}

export default App;