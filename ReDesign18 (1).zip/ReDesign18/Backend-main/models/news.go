package model

import (
	"time"
)

type News struct {
	ID             uint      `json:"id"`
	Title          string    `json:"title"`
	Content        string    `json:"content"`
	Author         string    `json:"author"`
	PublishedAt    time.Time `json:"publishedAt"`
	CommentCount   int       `json:"commentCount"`
	HeaderImageURL string    `json:"image"`
}

type NewsCardData struct {
	ID       uint   `json:"id"`
	Title    string `json:"title"`
	Date     string `json:"date"`
	Comments string `json:"comments"`
	Image    string `json:"image"`
}

func GetNewsDataForFrontend() []NewsCardData {
	newsList := []News{
		{
			ID:             1,
			Title:          "Kunjungan Fakultas Ilmu Komputer UNSRI ke IPB University: Studi Banding SPMI dan Pengembangan Unit",
			PublishedAt:    time.Date(2025, 7, 31, 0, 0, 0, 0, time.UTC),
			CommentCount:   0,
			HeaderImageURL: "https://placehold.co/180x101",
		},
		{
			ID:             2,
			Title:          "Pelepasan Secara Resmi Alumni ke-76 Mahasiswa dan Mahasiswi Fakultas Ilmu Komputer Universitas Sriwijaya",
			PublishedAt:    time.Date(2025, 6, 17, 0, 0, 0, 0, time.UTC),
			CommentCount:   0,
			HeaderImageURL: "https://placehold.co/180x101",
		},
		{
			ID:             3,
			Title:          "Akhiri Magang dengan Apresiasi: Fasilkom UNSRI dan Kantor Imigrasi Palembang Perkuat Sinergi",
			PublishedAt:    time.Date(2025, 7, 3, 0, 0, 0, 0, time.UTC),
			CommentCount:   0,
			HeaderImageURL: "https://placehold.co/180x101",
		},
	}

	var formattedNews []NewsCardData
	for _, news := range newsList {
		formattedNews = append(formattedNews, NewsCardData{
			ID:       news.ID,
			Title:    news.Title,
			Date:     news.PublishedAt.Format("02 January 2006"), 
			Comments: "Tidak ada komentar",
			Image:    news.HeaderImageURL,
		})
	}

	return formattedNews
}